# RecyclerView_In_Android

It's a simple recycleView project of android.
