package com.example.recyclelist

class Person(var name:String?,var desc:String?,var phonenumber:String?,var image:Int)